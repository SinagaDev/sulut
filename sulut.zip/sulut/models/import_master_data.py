from odoo import models, fields, api
from odoo.exceptions import UserError
import xlrd
import binascii
import tempfile

class ImportMasterData(models.TransientModel):
    _name = 'import.master.data'
    _description = 'Import Master Data'

    excel_file = fields.Binary('Excel File', required=True)
    file_name = fields.Char('File Name')
    tipe_import = fields.Selection([
        ('kegiatan', 'Kegiatan'),
        ('sub_kegiatan', 'Sub Kegiatan'),
        ('rekening', 'Rekening'),
        ('sumber_dana', 'Sumber Dana'),
        ('program', 'Program'),
    ], string='Import', required=True)

    def import_data(self):
        if not self.excel_file:
            raise UserError("Please upload an Excel file.")

        # Decode the Excel file
        with tempfile.NamedTemporaryFile(delete=False, suffix=".xlsx") as fp:
            fp.write(binascii.a2b_base64(self.excel_file))
            fp.seek(0)
            wb = xlrd.open_workbook(fp.name)
            sheet = wb.sheet_by_index(0)

            # Iterate through the rows in the Excel sheet
            for row_no in range(sheet.nrows):
                if row_no == 0:
                    continue  # Skip header row

                # Parse the row data
                line = list(map(lambda cell: isinstance(cell.value, bytes) and cell.value.decode('utf-8') or str(cell.value),
                                sheet.row(row_no)))

                code = str(line[0]).strip()
                name = str(line[1]).strip()
                values = {'code': code, 'name': name}

                # Call the appropriate handler based on the selected import type
                if self.tipe_import == 'kegiatan':
                    self._process_record('kegiatan', values)
                elif self.tipe_import == 'sub_kegiatan':
                    self._process_record('sub.kegiatan', values)
                elif self.tipe_import == 'rekening':
                    values['tipe_akun'] = str(line[2]).strip() if len(line) > 2 else ''
                    self._process_record('rekening', values)
                elif self.tipe_import == 'sumber_dana':
                    self._process_record('sumber.dana', values)
                elif self.tipe_import == 'program':
                    self._process_record('program', values)
                else:
                    raise UserError("Invalid Import Type.")

    def _process_record(self, model_name, values):
        """
        Process a record: search by code or name, update if exists, or create if not found.
        """
        model = self.env[model_name]

        # Search for existing records by code or name
        existing_record = model.search([('code', '=', values['code'])], limit=1)
        if existing_record:
            # Update name if code matches
            existing_record.write({'name': values['name']})
        else:
            existing_record = model.search([('name', '=', values['name'])], limit=1)
            if existing_record:
                # Update code if name matches
                existing_record.write({'code': values['code']})
            else:
                # Create a new record if no match is found
                model.create(values)
